
import os
import pandas as pd
from pathlib import Path

os.chdir(r'C:\Users\xenof\OneDrive\Рабочий стол\task_01')

PATH_TRANS = Path('invent_trans')
PATH_STOCK = Path('stock')

trans_files = sorted(PATH_TRANS.glob('*.csv'))
all_trans = []
for file in trans_files:
    df = pd.read_csv(file, sep=';', encoding='cp1251', low_memory=False)
    all_trans.append(df)
df_trans = pd.concat(all_trans, ignore_index=True)

df_trans['qty'] = pd.to_numeric(df_trans['qty'], errors='coerce').fillna(0)
df_trans['cost_amount'] = pd.to_numeric(df_trans['cost_amount'], errors='coerce').fillna(0)
df_trans['trans_date'] = pd.to_datetime(df_trans['trans_date'], format='%d.%m.%Y')

stock_file = list(PATH_STOCK.glob('*.csv'))[0]
df_stock = pd.read_csv(stock_file, sep=';', encoding='cp1251')
df_stock['qty'] = pd.to_numeric(df_stock['qty'], errors='coerce').fillna(0)
df_stock['cost_amount'] = pd.to_numeric(df_stock['cost_amount'], errors='coerce').fillna(0)

df_current = df_stock[['item_id', 'location_id', 'qty', 'cost_amount']].copy()
all_days = pd.date_range(start='2025-05-01', end='2025-07-31', freq='D')

results = []
for day in all_days:
    day_trans = df_trans[df_trans['trans_date'] == day]
    if len(day_trans) > 0:
        day_sum = day_trans.groupby(['item_id', 'location_id']).agg(
            day_qty=('qty', 'sum'),
            day_cost=('cost_amount', 'sum')
        ).reset_index()
        df_current = df_current.merge(day_sum, on=['item_id', 'location_id'], how='left')
        df_current['day_qty'] = df_current['day_qty'].fillna(0)
        df_current['day_cost'] = df_current['day_cost'].fillna(0)
        df_current['qty'] = df_current['qty'] + df_current['day_qty']
        df_current['cost_amount'] = df_current['cost_amount'] + df_current['day_cost']
        df_current = df_current[['item_id', 'location_id', 'qty', 'cost_amount']].copy()

    day_result = df_current.copy()
    day_result['trans_date'] = day.strftime('%d.%m.%Y')
    results.append(day_result)

df_all_days = pd.concat(results, ignore_index=True)
df_july_31 = df_all_days[df_all_days['trans_date'] == '31.07.2025']
df_july_31.to_csv('stock_2025_07_31.csv', sep=';', index=False, encoding='cp1251')
print("Готово!")
